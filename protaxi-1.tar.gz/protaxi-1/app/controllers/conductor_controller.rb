class ConductorController < ApplicationController
  layout 'conductor'
  def chofer1
  end
end
