class DashboardController < ApplicationController
  def home
  end

  def bookonline
  end

  def myrides
  end

  def myaccount
  end
  
  def contacto
  end
  
end
