class PanelController < ApplicationController
  layout 'admin'
  def servicios
  end

  def usuarios
  end

  def reportes
  end
end
